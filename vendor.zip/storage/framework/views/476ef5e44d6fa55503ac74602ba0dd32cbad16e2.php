<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo e($title ?? 'HOME'); ?> | Saurabh Jewel Pack</title>
    <meta name="description" content="<?php echo e(config('app.name')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(config('app.url')); ?>/images\logosjp.png" />


    <meta name="theme-color" content="#a7baff">
    <!--plugin-css-->

    <meta property="og:site_name" content="Saurav Jewel Pack">

    <meta property="og:type" content="website">
    <meta property="og:image" content="<?php echo e(config('app.url')); ?>/images/sauravlogo.png">

    <link rel="canonical" href="<?php echo e(config('app.url')); ?>">


    <meta name="description"
        content="Saurabh Jewel Pack, trusted since 1983, excels in providing exceptional packing services to jewelers. With unbeatable quality at affordable prices, they prioritize earning trust through their brand power and customer satisfaction.">
    <meta property="og:title" content="Saurav Jewel Pack">
    <meta property="og:description"
        content="Saurabh Jewel Pack, trusted since 1983, excels in providing exceptional packing services to jewelers. With unbeatable quality at affordable prices, they prioritize earning trust through their brand power and customer satisfaction.">



    <meta name="theme-color" content="#a7baff">
    <meta name="msapplication-TileColor" content="#a7baff">
    <meta name="msapplication-navbutton-color" content="#a7baff">
    <meta name="apple-mobile-web-app-status-bar-style" content="#a7baff">



    <?php echo $__env->make('visitors.inc.headerlinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('head'); ?>
    <style>
        html,
        body {
            overflow-x: hidden
        }
    </style>
</head>

<body>
    <!-- START PRELOADER -->

    <!-- END PRELOADER -->
    <!-- START HEADER SECTION -->
    <?php echo $__env->make('visitors.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END HEADER SECTION -->
    <!-- START SLIDER SECTION -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- END CLIENT SECTION -->
    <!-- START FOOTER -->

    <?php echo $__env->make('visitors.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('visitors.inc.footerlinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
    <!-- Latest jQuery -->
    <?php if(Session::has('success')): ?>
    <script>
        swal("Success", "<?php echo e(Session::get('success')); ?>", 'success', {
        buttons: {
            confirm: "OK",
        },
    });
    </script>
    <?php endif; ?>

</body>

</html>
<?php /**PATH D:\Git\SauravJewels\SJP-New\resources\views/visitors/layouts/visitors.blade.php ENDPATH**/ ?>