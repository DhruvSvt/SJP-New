<script type="text/javascript">
    $(document).ready(function() {
        $("#catlog").fancybox({
            'width': 450,
            'height': 450,
            'type': 'iframe'
        });

    });
</script>

<!-- Sweet Alert CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"
    integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- End Google Tag Manager (noscript) -->
<style>
    .dropdown-menu>li>a:hover,
    .dropdown-menu>li>a:focus {
        color: #ffffff;
        text-decoration: none;
        background-color: #2f3c69;
    }

    .dropdown-submenu {
        position: relative;
    }

    .dropdown-submenu>.dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: -6px;
        margin-left: -1px;
        -webkit-border-radius: 0 6px 6px 6px;
        -moz-border-radius: 0 6px 6px;
        border-radius: 0 6px 6px 6px;
    }

    .dropdown-submenu:hover>.dropdown-menu {
        display: block;
    }

    .dropdown-submenu>a:after {
        display: block;
        content: " ";
        float: right;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
        border-width: 5px 0 5px 5px;
        border-left-color: #ccc;
        margin-top: 5px;
        margin-right: -10px;
    }

    .dropdown-submenu:hover>a:after {
        border-left-color: #fff;
    }

    .dropdown-submenu.pull-left {
        float: none;
    }

    .dropdown-submenu.pull-left>.dropdown-menu {
        left: -100%;
        margin-left: 10px;
        -webkit-border-radius: 6px 0 6px 6px;
        -moz-border-radius: 6px 0 6px 6px;
        border-radius: 6px 0 6px 6px;
    }

    @media (min-width: 768px) {

        /*added by T Morphy */
        /*from http://www.barrykooij.com/bootstrap-submenu-open-on-mouse-over/ to get hover behaviour on desktop */
        ul.nav li.dropdown:hover ul.dropdown-menu {
            display: block;
        }

        ul.nav li.dropdown:hover ul.dropdown-menu li.dropdown-submenu ul.dropdown-menu {
            display: none;
        }

        ul.nav li.dropdown ul.dropdown-menu li.dropdown-submenu:hover ul.dropdown-menu {
            display: block;
        }

        .lead {
            font-size: 21px;
        }
    }
</style>
<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-xs-12 col-sm-6">
                <div class="mobilenumbers">
                    <!-- <a href="https://api.whatsapp.com/send?phone=919321177663&amp;text=" target="_blank" class="call"><img src="<?php echo e(config('app.url')); ?>/images/icon-whatsapp.png" alt="" />93211 77663</a> <span class="separator">|</span> -->
                    <a href="javascript:;" class="call"><img src="<?php echo e(config('app.url')); ?>/images/footer_callus.png"
                            width="21" alt="" />932292392</a> <span class="separator">|</span> <a href="javascript:;"
                        class="call" src="<?php echo e(config('app.url')); ?>/images/footer_callus.png" width="21" alt="" />99206
                    50797</a>
                </div>

                <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img
                        src="<?php echo e(config('app.url')); ?>\images\sauravlogo.png" class="img-responsive"
                        alt="Saurav Jewel Pack" title="Saurav Jewel Pack"></a>
            </div>
            <div class="col-md-7 col-xs-12 col-sm-6">
                <div class="head_right">
                    <ul class="list-unstyled" style="padding-top: 34px;">
                        <li>
                            <!-- <a href="https://api.whatsapp.com/send?phone=919321177663&amp;text=" target="_blank" class="call"><img src="<?php echo e(config('app.url')); ?>/images/icon-whatsapp.png" alt="" />93211 77663</a> <span class="separator">|</span> <a href="javascript:;" class="call"><img src="<?php echo e(config('app.url')); ?>/images/footer_callus.png" width="21" alt="" />93222 17216</a> <span class="separator">|</span> -->
                            <a href="tel:9548942643" class="call"><i class="fa fa-phone"></i>&nbsp;+91 9548942643</a>
                            <span class="separator">|</span>
                            <a href="tel:5623531556" class="call"><i class="fa fa-phone"></i>&nbsp;+91 5623531556</a>
                            <span class="separator">|</span>
                            <a href="mailto:s.jewelpack@gmail.com" class="call"><i class="fa fa-map-marker"></i>&nbsp;
                                s.jewelpack@gmail.com</a>
                        </li>



                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Navigation -->
<nav class="navbar navbar-inverse navbar-static-top" role="navigation">
    <div class="container" style="margin-top: 0;">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <span class="topicons">
                <!--<a href="https://api.whatsapp.com/send?phone=919321177663&amp;text=" target="_blank"><img src="<?php echo e(config('app.url')); ?>/images/icon-whatsapp.png" alt="" /></a>
     -->
                <a href="tel:9548942643"><img src="<?php echo e(config('app.url')); ?>/images/footer_callus.png" width="21"
                        alt="" /></a>
                <a href="tel:5623531556"><img src="<?php echo e(config('app.url')); ?>/images/icon-call2.png" height="20"
                        alt="" /></a>

                <a href="mailto:s.jewelpack@gmail.com"><img src="<?php echo e(config('app.url')); ?>/images/mail.png"></a>
            </span>
            <button type="button" class="navbar-toggle" data-toggle="collapse"
                data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav ">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('company-profile')); ?>">Company Profile</a></li>
                <li class="dropdown"><a href="<?php echo e(route('our-product')); ?>" data-toggle="dropdown"
                        class="dropdown-toggle enable">Our Products&nbsp;<span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <?php
                        $Footer_gallery = TCG\Voyager\Models\Category::orderBy('order', 'ASC')
                        ->whereNull('parent_id')
                        ->get();
                        ?>

                        <?php $__currentLoopData = $Footer_gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $id = $row->id;
                        $Footer_gallery1 = TCG\Voyager\Models\Category::where('parent_id', $id)
                        ->orderBy('order', 'ASC')
                        ->get();
                        ?>
                        <?php if($Footer_gallery1->count() >= 1): ?>
                        <li class="dropdown-submenu"><a href="#" class="dropdown-toggle enable"><?php echo e($row->name); ?>&nbsp;
                                <!--<span class="caret"></span>-->
                            </a>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $Footer_gallery1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('category', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <?php else: ?>
                        <li><a href="<?php echo e(route('category', $row->slug)); ?>"><?php echo e($row->name); ?></a></li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </li>

                <li><a href="<?php echo e(route('contact-us')); ?>">Contact us</a></li>
                

            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>

<div class="flt-enq">
    <img src="<?php echo e(config('app.url')); ?>/images/eimg2.png" class="quick-enq" />

    <div class="enq-form">
        <div class="head2">Quick Enquire us</div>
        <form name="request_quote" id="request_quote" method="POST" enctype="multipart/form-data"
            action="<?php echo e(route('formaction')); ?>" class="">
            <?php echo csrf_field(); ?>
            <input name="act" id="act" type="hidden" value="request_quote" /> <input name="cur_page" id="cur_page"
                type="hidden" value="/" />
            <div class="form-group">
                <label for="formGroupExampleInput">Full Name</label>
                <input type="text" name="person_name" class="form-control" id="formGroupExampleInput"
                    placeholder="Enter Full Name" required>
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Email ID</label>
                <input type="email" name="email" class="form-control" id="formGroupExampleInput2"
                    placeholder="Enter Valid Email ID" onblur="return check_validation();">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput3">Contact No</label>
                <input type="tel" name="contact" class="form-control" id="formGroupExampleInput3"
                    placeholder="Enter Contact No" pattern="[6-9]{1}[0-9]{9}"
                    title="Phone number with 6-9 and remaing 9 digit with 0-9" onblur="return check_validation();"
                    required>
            </div>

            <div class="form-group">
                <label for="formGroupExampleInput4">City</label>
                <input type="tel" name="city" class="form-control" id="formGroupExampleInput4"
                    placeholder="Enter City Name" onblur="return check_validation();" required>
            </div>

            <input type="submit" class="btn-orange" value="Send Enquiry" />
        </form>
    </div>
</div>


<script>
    function check_validation() {
        var email = $('#formGroupExampleInput2').val();
        var contact = $('#formGroupExampleInput3').val();
        //alert(contact.length);
        if (email != '') {
            var atpos = email.indexOf("@");
            var dotpos = email.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length) {
                alert("Please Provide Valid Email");
                return false;
            }
        }
        if (contact != '' && (contact.length < 10 || isNaN(contact))) {
            alert("Please Enter Valid Contact.");
            return false;
        }
        //alert("hello");
    }
</script>
<?php /**PATH D:\Git\SauravJewels\SJP-New\resources\views/visitors/inc/header.blade.php ENDPATH**/ ?>