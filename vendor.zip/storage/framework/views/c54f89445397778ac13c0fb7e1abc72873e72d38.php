<?php $__env->startSection('content'); ?>
    <!-- Header Carousel -->
    <div id="myCarousel" class="carousel slide home-slider">
        <!-- Indicators -->


        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <!--<div class="item active">
                        <div class="nocontainer">
             <div class="row">
              <div class="col-md-12"><img src="images/ppinds_banner.jpg" class="slider_img_full" alt="slider image"></div>
             </div>
            </div>
                    </div>-->
            <!--<div class="item active">
                        <div class="nocontainer">
             <div class="row">
              <div class="col-md-12"><img src="images/website-banner-01.jpg" class="slider_img_full" alt="slider image"></div>
             </div>
            </div>
                    </div>-->
            <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item <?php if($loop->index == 0): ?> active <?php endif; ?>">
                    <div class="nocontainer">
                        <div class="row">
                            <div class="col-md-12"><img src="<?php echo e(Voyager::image($row->image)); ?>" class="slider_img_full"
                                    alt="slider image"></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </div>

    <div class="section welcome">
        <div class="container">
            <div class="head1">Welcome To SJP</div>
            <div style="text-align: center">
                <img class="reset-width" src="<?php echo e(config('app.url')); ?>\images\jewelbg.png">
            </div>
            <hr>
            <div class="content">
                <p style="font-size: 1.5rem">We are available to assist you with any needs you may have. We can meet all
                    of your needs with simply a phone call. We
                    are committed to providing our customers with a range of high-quality services that will result in
                    complete
                    satisfaction. Give us a call or send us an email to obtain the amazing “PPI” experience with assured
                    fixes. We are here
                    to assist you around-the-clock.</p>
                <br>
                <p style="font-size: 1.5rem">Our area of expertise is serving retail jewelry segments, diamond
                    boutiques, and gold showrooms. We produce a wide range
                    of goods, mostly for the gold and diamond jewelry markets, including jewelry boxes, plastic
                    boxes, jewelry bags, jute
                    bags, purses, handbags, and gold coin packing cards.</p>

            </div>



        </div>
    </div>
    </div>

    <br>
    <div class="section products">
        <div class="container">
            <div class="head1">Product Category</div>
            <div style="text-align: center">
                <img class="reset-width" src="<?php echo e(config('app.url')); ?>\images\jewelbg.png" </div>
                <hr>
                <!--<div id="owl-demo">-->
                <div class="row" style="display: flex;  flex-wrap: wrap;">
                    <div id="owl-demo4">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <a href="<?php echo e(route('category', $row->slug)); ?>" class="hvr-bounce-to-bottom product">
                                    <div class="prod_box">
                                        
                                        <div class="prod_title"><?php echo e($row->name); ?></div>
                                    </div>
                                </a>
                                <a href="<?php echo e(route('category', $row->slug)); ?>" class="hvr-bounce-to-bottom product">
                                    <div class="prod_box">
                                        
                                        <div class="prod_title"><?php echo e($row->name); ?></div>
                                    </div>
                                </a>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <br>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('visitors.layouts.visitors', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git\SauravJewels\SJP-New\resources\views/visitors/index.blade.php ENDPATH**/ ?>