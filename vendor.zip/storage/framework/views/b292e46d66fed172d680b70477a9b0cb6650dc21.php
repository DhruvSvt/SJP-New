<?php $__env->startSection('content'); ?>





<div class="section welcome">
    <div class="container">
        <div class="head1">Welcome To SJP</div>
        <div style="text-align: center">
            <img class="reset-width" src="<?php echo e(config('app.url')); ?>\images\jewelbg.png" </div>
            <hr>
            <p class="row"><b>SJP is committed to offering premium goods with cutting-edge designs and the highest caliber. We produce a wide range of
            gift items, including calendars, diaries, conference notepads, wall and table clocks, desk calendars, bags, mugs, key
            chains, pen drives, and gift pens, to name a few. We create products based on the demands and preferences of each
            individual client while also considering the brand appeal that the product should have with its intended market.</b></p>
         </div>
    </div>

        <!-- /.row -->

        <div class="innercontent">

             <!-- Intro Content -->

            <div class="row">

                <div class="col-md-5">

                    <img class="img-responsive fullimg" src="images/" alt="">

                </div>

                <div class="col-md-7">

                    <div class="head2"><b>About Saurabh Jewel Pack</b></div>
                    <div style="text-align: center">
                        <img class="reset-width" src="<?php echo e(config('app.url')); ?>\images\jewelbg.png" </div>
                        <hr>



					<p><b>In field of Provide a Great Service to jewellers as Packing providers, Saurabh Jewel Pack Have a Great Trust Since 1983,
                    This company is doing an Excellent work in the market Since last 41 years, Thousands Of happy customers are with us,
                    Earning Trust is More Important than earning anything else, SJP strongly Believes in This and though we provide you The
                    Unbeatable Quality With Unbearable Prices, There Are much jewellery packing providers in market but we beleive Brand
                    power we hold is because of our quality, simply saying the Quality of packing, You provide to Customer, Is Directly
                    connected with Your impression on them. As for that problem Saurabh Jewel Pack Comes On your Way a Great Solution.<</p>



					

                </div>

            </div>

            <!-- /.row -->

            <hr />

            <!-- Intro Content -->

            

            <!-- /.row -->

            <div class="section clients">

                <div class="head1"><b>Our Valuable Customers</b></div>
                <div style="text-align: center">
                    <img class="reset-width" src="<?php echo e(config('app.url')); ?>\images\jewelbg.png" </div>
                    <hr>

                <div id="owl-demo3">

                    <div class="item">

                        <div class="client_box">

                            <img src="uploads/client-logo/JOYALUKAS.jpg" alt="Joyalukkas World favourite jeweller">

                        </div>

                    </div>

                    <div class="item">

                        <div class="client_box">

                            <img src="uploads/client-logo/KALYAN.jpg" alt="Kalyan Jewellers">

                        </div>

                    </div>

                    <div class="item">

                        <div class="client_box">

                            <img src="uploads/client-logo/KONSTELEC.jpg" alt="Konstelec engineers pvt ltd">

                        </div>

                    </div>

                    <div class="item">

                        <div class="client_box">

                            <img src="uploads/client-logo/MALABAR.jpg" alt="Malabar Gold and Diamonds">

                        </div>

                    </div>

                    <div class="item">

                        <div class="client_box">

                            <img src="uploads/client-logo/ROYAL.jpg" alt="Royal Embroidery Yarn">

                        </div>

                    </div>



                </div>

            </div>

        </div>



    </div>

<hr>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('visitors.layouts.visitors',['title' => 'about-us'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git\SauravJewels\resources\views/visitors/about-us.blade.php ENDPATH**/ ?>